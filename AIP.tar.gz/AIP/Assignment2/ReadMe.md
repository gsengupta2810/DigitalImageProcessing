Use ./out <arg1> <arg2> 
arg1 = image 1
arg2 = image 2

select atleast 4 points in image 1 and then select corrosponding points in image2. Make sure equal number of points are selected.
Press enter/space bar to see the homography calculated matrix in the terminal 
The good matches based on SIFT descripters will be then displayed.