To execute color correction use ./part1
Three types of corrections have been implemented- Von Kries CAT, BFD and Sharp. 
The outputs are stored in the corrected image folder. To run one type of correcton uncomment that line in the main function in part1.cpp
For saturated_desaturated image run ./out
 