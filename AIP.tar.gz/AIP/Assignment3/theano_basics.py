import numpy as np
import theano.tenor as T