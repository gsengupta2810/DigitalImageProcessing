To build all files use make in the Assignment1 directory.
Some of the output images get stored in the output directory, while some others are displayed durint execution.
The codes are in :-
one.cpp
two.cpp
harris.cpp

The file plot.py is to plot the PSNR values for the three images.
The outputs are one two three and four named executables.
